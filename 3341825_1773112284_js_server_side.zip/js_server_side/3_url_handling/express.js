// importing the modules
var http = require('http'); // server
var url = require('url'); // url handling
var fs = require('fs'); // file handling

// create a server
http.createServer(function (req, res) {
    // requested url
    var q = url.parse(req.url, true);
    // filename requested from the user
    var filename = "." + q.pathname;
    // read the file and serve the contents to the client
    fs.readFile(filename, function(err, data) {
        // error handling
        if (err) {
            // write a response
            res.writeHead(404, {'Content-Type': 'text/html'});
            return res.end("404 Not Found");
        }
        // return the data
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write(data);
        return res.end();
    });
    // listening on a certain port
}).listen(80);