const port = 80; // listening port

// import the express module
const express = require('express');

// initialize the express app module
const app = express();

// store the data in a json object
JsonObj = {
    "firstname": "moses",
    "lastname": "Curl",
    "email": "curlm@mail.com",
    "address": 25514,
    "phone": "0253255544",
    "verified": true
};

// stringify the json data
dbParam = JSON.stringify(JsonObj);

// configure the routes
app.get('/', (req, res) => {
    // send the response
    // return the data to the user
    res.json(dbParam); // return the array with the data
});

app.listen(port, () => {
    console.log("Ok on " + port);
});

