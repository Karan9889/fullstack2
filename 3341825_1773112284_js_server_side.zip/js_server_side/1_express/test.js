var http = require('http');
var url = require('url');

// import the express module
const express = require('express');

// initialize the express app module
const app = express();

// configure the routes
app.get('/', (req, res) => {
    // send the response
    res.send('Hello World ');
});

http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    var q = url.parse(req.url, true).query;
    var txt = q.year + " " + q.month;
    res.end(txt);
}).listen(8080, () => {
    console.log("http://127.0.0.1:8080");
});