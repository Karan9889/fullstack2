const http = require('http'); // import the http module

// set the hostname
const hostname = '127.0.0.1';

// set the port
const port = 999;

// create  server object
const server = http.createServer((req, res) => {
	// response
	res.statusCode = 200;
	res.setHeader('Content-Type', 'text/plain');
	// content to be displayed
	res.end('Hello World \n');
});

// call the server object instance
// listening for incoming connections
server.listen(port, hostname, () => {
	console.log(`http://${hostname}:${port}/` + 'ok');
});

