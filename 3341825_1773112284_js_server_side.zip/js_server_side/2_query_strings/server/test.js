const port = 999;

// import the express module
const express = require('express');

// initialize the express app module
const app = express();

// configure the routes
app.get('/', (req, res) => {
	// send the response 
	res.send('Hello World ');
});

app.listen(port, () => {
	console.log("Ok on " + port);
});

