// importing the required modules
var http = require('http');
var url = require('url');
var fs = require('fs');


// file serving server
http.createServer( (req, res) => {
	// capture  query from the client
	var query = url.parse(req.url, true);
	// filename requested by the user
	var file  = query.pathname + file;
	// read the file if present and server its contents
	fs.readFile(file, function(err, data) {
		// check for errors
		if(err) {
			res.writeHead(404, {'Content-Type': 'text/html'});
			return res.end('404 Not found');
		}
		res.writeHead(404, {'Content-Type': 'text/html'});
		res.write(data);
		return res.end();
	});
}).listen(80);
