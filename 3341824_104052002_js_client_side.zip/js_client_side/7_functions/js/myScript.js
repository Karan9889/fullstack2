// function to do something
function doSomething() {
    // parse the number from the input
    var aNumber = document.getElementById("firstname");
    if(!aNumber.checkValidity()) {
        // validate the input number
        window.onload = function () {
            document.getElementById("resultMessage").innerHTML = aNumber.validationMessage;
        }
    }
    window.onload = function () {
        document.getElementById("resultMessage").innerHTML = aNumber;
    }
}

function doSomething1() {
    // parse the number from the input
    const aNumber = document.getElementById("aNumber");
    if(!aNumber.checkValidity()) {
        // validate the input number
        document.getElementById("resultMessage").innerHTML = aNumber.validationMessage;
    }
    window.onload = function () {
        document.getElementById("resultMessage").innerHTML = aNumber;
    }
}
function doSomething2() {
    // parse the number from the input
    const aNumber = document.getElementById("aNumber");
    if(!aNumber.checkValidity()) {
        // validate the input number
        document.getElementById("resultMessage").innerHTML = aNumber.validationMessage;
    }
    window.onload = function () {
        document.getElementById("resultMessage").innerHTML = aNumber;
    }
}


try {
    //
} catch (e) {
    alert(e.message);
} finally {
    console.log("success");
}