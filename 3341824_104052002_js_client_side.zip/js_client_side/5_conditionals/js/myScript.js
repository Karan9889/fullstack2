// store elements in variables and display
// array containing the items
var words = ["Orange ", "Vol", "Banana"];
var numbers =  [1, 2, 3];
var text;

// assign letter to numbers and numbers to letters
var letter_1 = "B";
var number_1 = 2;


// function to display the items
function displayElements () {
    window.onload = function () {
        f();
        function f() {
            let i;
            // document.getElementById("demo").innerHTML = e;
            for (var _i = 0 ; _i <= words.length; _i++) {
                if (words[_i] === letter_1) {
                    text = "<ul>";
                    for (i = 0; i < words.length; i++) {
                        displayElements_(words[i]);
                    }
                    text += "</ul>";
                    document.getElementById("demo").innerHTML = text;
                } else {
                    text = "<ul>";
                    for (i = 0; i < words.length; i++) {
                        displayElements_(words[i]);
                    }
                    text += "</ul>";
                    document.getElementById("demo").innerHTML = text;
                }
            }
        }
        function displayElements_(value) {
            text += "<li>" + value + "</li>";
        }
    }
}

try {
    displayElements(words);
} catch (e) {
    alert(e.message);
} finally {
    console.log("success");
}