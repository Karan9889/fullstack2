// display hello world in the instance of index.html
let displayMessage = (msg) => {
   window.alert(msg);
};

// call the function to display the hello message
// error handling
try {
    //
    displayMessage("Hello, Welcome .. ");
} catch (e) {
    document.getElementById("err").innerHTML = e.message;
} finally {
    // always executed
    console.log("OK");
}