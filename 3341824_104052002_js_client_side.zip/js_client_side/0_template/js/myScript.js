// display hello world in the instance of index.html
let displayHello = () => {
    document.getElementById("hello").innerHTML = "Hello world !!";
};

// call the function to display the hello message
// error handling
try {
    displayHello();
} catch (e) {
    document.getElementById("err").innerHTML = e.message;
} finally {
    // always executed
}