// display the information about the items in the list
var items, text;
items = ["Banana", "Orange", "Apple", "Mango"];

window.onload = function () {
    f();
  function f() {
      text = "<ul>";
      for (var i = 0; i < items.length; i++) {
          displayElements(items[i]);
          alert(items[i]);
      }
      text += "</ul>";
      document.getElementById("demo").innerHTML = text;
  }
};

function displayElements(value) {
    text += "<li>" + value + "</li>";
}

// error handling
try {
    f();
} catch (e) {
    // catch the error  and log to the console
    console.log(e.message);
} finally {
    // always executed
    console.log("success");
}