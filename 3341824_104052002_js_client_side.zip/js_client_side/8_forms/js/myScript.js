// function

function somethingHappened() {
    var firstname = document.getElementById("firstname").value;
    var lastname = document.getElementById("lastname").value;
    let someData = {
        firstname: firstname,
        lastname: lastname
    };
    // check if data provided
    if (someData.length !== 0) {
        // log the data to the console
        console.log(someData);
        window.onload = function () {
            document.getElementById('result').innerHTML = someData;
            document.getElementById("click").onclick = function () {
                // button clicked
                alert(someData);
            }
        }
    } else {
        window.location = "other.html";
    }
}

try {
    somethingHappened();
} catch (e) {
    alert(e.message);
} finally {
    //
}