// store elements in variables and display
// array containing the items
var words = ["Saab ", "Volvo ", "BMW "];
var numbers =  [1, 2, 3];

// concatenate the arrays
var con = words.concat(numbers);

// function to do something
function doSomething(someData) {
    // return some data
    return someData;
}
// function to display the items
function displayElements (e) {
    window.onload = function () {
        f();
        function f() {
            document.getElementById("demo").innerHTML = e;
        }
    }
}

try {
    displayElements(con);
} catch (e) {
    alert(e.message);
} finally {
    console.log("success");
}